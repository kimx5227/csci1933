For this project, I worked by myself. LinkedList and ArrayList both include all the methods listed in the list
interface as well as the ArrayList having a resize method. Everything should work as accordingly, as the Junit
tests all run correctly.