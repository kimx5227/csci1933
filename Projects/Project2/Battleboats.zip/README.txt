Blake Kim - kimx5227
My program has no major additional features. Some minor changes may include correction of user input.
User of program should compile both the BattleboatsBoard.java and BattleboatsGame.java files and the
main method is located in the BattleboatsGame file. So, to run the game, you should run the BattleboatsGame
file. There are no known bugs or defects to the program, everything should run smoothly.
